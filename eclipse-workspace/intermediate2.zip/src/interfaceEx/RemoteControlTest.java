package interfaceEx;

public class RemoteControlTest {

}
