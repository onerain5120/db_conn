package interfaceEx;

public class Audio {

}
