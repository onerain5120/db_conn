package interfaceEx;

public class Television {

}
