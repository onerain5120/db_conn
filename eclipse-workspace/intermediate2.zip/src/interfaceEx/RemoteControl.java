package interfaceEx;

public interface RemoteControl {

	// 상수
	
	
	// 추상메서드
	
	
	// 디폴드메서드
	
	
	// 정적메서드
	
	
	
}
