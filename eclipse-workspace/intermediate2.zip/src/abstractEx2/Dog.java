package abstractEx2;

public class Dog extends Animal {

	
	@Override
	void sound() {
		System.out.println("뭉뭉");
	}
	
}
