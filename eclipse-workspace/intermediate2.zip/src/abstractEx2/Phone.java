package abstractEx2;

public class Phone {

}
