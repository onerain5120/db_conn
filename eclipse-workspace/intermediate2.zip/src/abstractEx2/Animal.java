package abstractEx2;

public abstract class Animal {

	// 추상 메서드
	abstract void sound();


	// 일반 메서드
	void move() {
		System.out.println("움직인다.");
	}

}
