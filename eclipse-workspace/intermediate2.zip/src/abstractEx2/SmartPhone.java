package abstractEx2;

public class SmartPhone extends Phone{

}
