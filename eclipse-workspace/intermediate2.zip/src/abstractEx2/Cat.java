package abstractEx2;

public class Cat extends Animal {

	@Override
	void sound() {
		System.out.println("야옹");
	}
	
	
	
}
