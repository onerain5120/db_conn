package cafe;

public class BeanCafe {
	
	// 필
	int money;
	int amePrice = 4000;
	int lattePrice = 4500;
	String name = "콩 다방";
	
	
	// 생

	public BeanCafe() {
		
	}
	
	// 메
	void ame() {
		money += 4000;
	}
	
	void latte() {
		money += 4500;
	}
	
	
}





