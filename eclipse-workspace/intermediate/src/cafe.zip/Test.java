package cafe;

public class Test {

	public static void main(String[] args) {
		Person kim = new Person("Kim", 10000);
		StarCafe star= new StarCafe();
		System.out.println(kim.name + " 님께서는 " + star.amePrice + "원을 내고 별 다방 " + kim.starAme(star));
		System.out.println(kim.name + " 님의 잔돈은 " + kim.money + "원 입니다.");
		System.out.println(star.name + "의 수익은 " + star.money + "원 입니다.");
		
		System.out.println("--------------------------------");
		
		Person lee = new Person("Lee", 10000);
		BeanCafe bean= new BeanCafe();
		System.out.println(lee.name + " 님께서는 " + bean.lattePrice + "원을 내고 별 다방 " + lee.beanLatte(bean));
		System.out.println(lee.name + " 님의 잔돈은 " + lee.money + "원 입니다.");
		System.out.println(bean.name + "의 수익은 " + bean.money + "원 입니다.");

	}
	
}
