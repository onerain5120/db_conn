package cafe;

public class StarCafe {

	// 필
	int money;
	int amePrice = 4000;
	int lattePrice = 4500;
	String name = "별 다방";
	
	// 생
	
	public StarCafe() {
		
	}
	
	// 메

	void ame() {
		money += 4000;
	}
	
	void latte() {
		money += 4500;
		
	}
	
}
