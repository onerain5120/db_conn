package cafe;

public class Person {


	// 필
	String name;
	int money;
	
	
	// 생
	public Person() {
		
	}
	
	public Person(String name, int money) {
		this.name = name;
		this.money = money;
	}
	
	// 메
	String starAme(StarCafe star) {
		star.ame();
		money -= 4000;
		return "아메리카노를 구입했습니다." ;
	}
	
	String starLatte(StarCafe star) {
		star.latte();
		money -= 4500;
		return "라떼를 구입했습니다." ;
	}
	
	String beanAme(BeanCafe bean) {
		bean.ame();
		money -= 4000;
		return "아메리카노를 구입했습니다." ;
	}
	
	String beanLatte(BeanCafe bean) {
		bean.latte();
		money -= 4500;
		return "라떼를 구입했습니다." ;
	}
	
	
	
	
	
	
//	void latte() {
//		System.out.println("라떼를 구입했습니다.");
//	}
	

	
}
